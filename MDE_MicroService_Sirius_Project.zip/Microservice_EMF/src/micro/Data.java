/**
 */
package micro;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Data</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see micro.MicroPackage#getData()
 * @model
 * @generated
 */
public interface Data extends NamedElement {
} // Data
